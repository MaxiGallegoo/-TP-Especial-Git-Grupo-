<?php
$prov = "Bs As";
$ciudad = "Tandil";
 ?>
