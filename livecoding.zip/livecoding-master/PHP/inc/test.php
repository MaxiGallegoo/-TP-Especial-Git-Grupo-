<?php
// Todavia no se incluyo el archivo
echo "Origen $ciudad $prov"; // Origen
include 'localidades.php';
include 'localidades.php';
include 'localidades.php';
include 'localidades.php';
include 'localidades.php';
// Ahora sí, las variables toman valor
echo "Origennnnnnnnnnn $ciudad $prov";//Origen Tandil-BA
?>
