<?php
$prov = 'BA';
$ciudad = 'Tandil';
?>
