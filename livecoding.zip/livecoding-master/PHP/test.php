<?php

$ape = $_GET['apellido'];

var_dump($ape);

?>
