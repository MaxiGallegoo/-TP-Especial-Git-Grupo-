Livecoding
==========

Commits de los codigos realizados en clase, con sus los mismos errores y chistes
de las clases
