<?php

function MostrarPi(){
  $resultado = pi();

  echo "<h1>Resultado PI: $resultado</h1>";
}

 ?>
