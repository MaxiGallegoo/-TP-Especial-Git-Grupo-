<?php

function Sumar($valor1, $valor2){

  $resultado = $valor1 + $valor2;

  echo "<h1>Resultado: $resultado</h1>";
}



 ?>
